def book_info(): 
    print("="*50) 
    print("\n") 
    print(" "*10,"WELCOME TO OUR BOOKSHELVES"," "*10) 
    print("\n") 
    print("="*50) 
    print("Please select wishes type of book/magazine.") 
    print(" >>>TYPE 0 when finished shopping<<< ") 
    print("-"*50) 
    print("1. Children Book") 
    print("2. TextBook") 
    print("3. Fiction") 
    print("4. Magazine") 
    print("5. Non-fiction") 
    print("-"*50) 
    book_type=input("Number of book's type:") 
    print("*"*50) 
    if book_type == "1" : 
        with open("children.txt") as file1 : 
            for a in file1: 
                print(a) 
                print("*"*50) 
    elif book_type == "2" : 
        with open("textbook.txt") as file2 : 
            for b in file2: 
                print(b) 
                print("*"*50) 
    elif book_type == "3": 
        with open("fiction.txt") as file3: 
            for c in file3: 
                print(c) 
                print("*"*50) 
    elif book_type == "4" : 
        with open("mag.txt") as file4: 
            for d in file4: 
                print(d) 
                print("*"*50) 
    elif book_type == "5": 
        with open("nonfic.txt") as file5: 
            for e in file5:
                print(e) 
                print("*"*50) 
    else : 
        print(">>>No Information.") 
    return book_type 

def book_collect(bookinfo): 
    system= False 
    if bookinfo== "1": 
        question= input("C=Continue,Q=quit :") 
        while not system: 
            if question=="c"or question=="C": 
                book_name= input("Selected book no. :") 
                book_amount= int(input("Amount: ")) 
                bookamt.append(book_amount) 
                question= input("C=Continue,Q=quit :") 
                with open("children.txt") as file1: 
                    data1= file1.read().splitlines() 
                    for x in data1: 
                        line1=x.split() 
                        if line1[0]==book_name: 
                            book_name=line1[1] 
                            bookname.append(book_name) 
                            price=int(line1[2])*book_amount 
                            bookprice.append(price) 
                    else: 
                        print("Already quit from children books.") 
                        print("-"*50) 
                        system=True 
    elif bookinfo== "2": 
        question= input("C=Continue,Q=quit :") 
        while not system: 
            if question=="c"or question=="C": 
                book_name= input("Selected book no. :") 
                book_amount= int(input("Amount: ")) 
                bookamt.append(book_amount) 
                question= input("C=Continue,Q=quit :") 
                with open("textbook.txt") as file2: 
                    data2= file2.read().splitlines() 
                    for x in data2: 
                        line2=x.split() 
                        if line2[0]==book_name: 
                            book_name=line2[1] 
                            bookname.append(book_name) 
                            price=int(line2[2])*book_amount
                            bookprice.append(price) 
                        else: 
                            print("Already quit from Textbooks.") 
                            print("-"*50) 
                            system=True 
    
    elif bookinfo== "3": 
        question= input("C=Continue,Q=quit :") 
        while not system: 
            if question=="c"or question=="C": 
                book_name= input("Selected book no. :")
                book_amount= int(input("Amount: ")) 
                bookamt.append(book_amount) 
                question= input("C=Continue,Q=quit :") 
                with open("fiction.txt") as file3: 
                    data3= file3.read().splitlines() 
                    for x in data3: 
                        line3=x.split() 
                        if line3[0]==book_name: 
                            book_name=line3[1] 
                            bookname.append(book_name) 
                            price=int(line3[2])*book_amount 
                            bookprice.append(price) 
                        else: 
                            print("Already quit from Fiction books.") 
                            print("-"*50) 
                            system=True 
    elif bookinfo== "4": 
        question= input("C=Continue,Q=quit :") 
        while not system: 
            if question=="c"or question=="C": 
                book_name= input("Selected book no. :") 
                book_amount= int(input("Amount: ")) 
                bookamt.append(book_amount) 
                question= input("C=Continue,Q=quit :") 
                with open("mag.txt") as file4: 
                    data4= file4.read().splitlines() 
                    for x in data4: 
                        line4=x.split() 
                        if line4[0]==book_name: 
                            book_name=line4[1] 
                            bookname.append(book_name) 
                            price=int(line4[2])*book_amount 
                            bookprice.append(price) 
                        else: 
                            print("Already quit from Magazines.") 
                            print("-"*50) 
                            system=True 
    elif bookinfo== "5": 
        question= input("C=Continue,Q=quit :") 
        while not system: 
            if question=="c"or question=="C": 
                book_name= input("Selected book no. :") 
                book_amount= int(input("Amount: ")) 
                bookamt.append(book_amount) 
                question= input("C=Continue,Q=quit :") 
                with open("nonfic.txt") as file5: 
                    data5= file5.read().splitlines() 
                    for x in data5: 
                        line5=x.split() 
                        if line5[0]==book_name: 
                            book_name=line5[1] 
                            bookname.append(book_name) 
                            price=int(line5[2])*book_amount 
                            bookprice.append(price) 
                        else: 
                            print("Already quit from Non-Fiction books.") 
                            print("-"*50) 
                            system=True 
    return bookname,bookprice,bookamt 

def dis_cal(fbookprice): 
    total=0 
    all=sum(list(fbookprice)) 
    if all>300 and all<1000 : 
        total= all*0.95 
    elif all>1000 and all<2500 : 
        total= all*0.88 
    elif all>2500 and all<5000 : 
        total= all*0.77 
    elif all>5000 and all<10000 : 
        total= all*0.66 
    elif all>10000 : 
        total= all*0.58 
    else: 
        total=all 
    return total 

def book_gift(discal): 
    if discal>=500 and discal<1500 :
        gifts="-50THB Discount Coupon for NEXT reached 600THB shopping" 
    elif discal>=1500 and discal<5000 : 
        gifts="-200THB Discount Coupon for NEXT reached 600THB shopping\n-A5 Postcards X4\n 40% Discount for membership Sign-up" 
    elif discal>=5000 and discal<10000 : 
        gifts="-300THB Discount Coupon for NEXT reached 600THB shopping\n-A5 Postcards X5\n Free for membership Sign-up\n-Food & Beverages Discount Coupon" 
    elif discal>=10000 : 
        gifts= "-300THB Discount Coupon for NEXT reached 600THB shopping\n-A5 Postcards X5\n Free for membership Sign-up\n-Food & Beverages Discount Coupon\n Five-star Hotel Voucher" 
    else: 
        gifts="-None" 
    return gifts 

def book_receipt(): 
    print("Total= ",discal) 
    cash=int(input("Cash: ")) 
    change=cash-discal 
    print("\n"*2) 
    print("V"*60) 
    print("\n"*2) 
    print(" "*25,"RECEIPT"," "*25) 
    print("\n"*2) 
    print("-"*60) 
    print("Customer: ",customer.upper()) 
    print("Cashier: ",cashier.upper()) 
    print("-"*60) 
    print("%s%35s%9s"%("Book's name","Amount","Price")) 
    for x in range(len(fbookname)): 
        print('{:40}'.format(fbookname[x]),end='') 
        print('{:^10}'.format(fbookamt[x]),end='') 
        print('{:^5}'.format(fbookprice[x])) 
    print("-"*60) 
    print("TOTAL") 
    print("*********") 
    print("Cash%50d"%cash) 
    print("Price%49d"%discal) 
    print("Change%48d"%change) 
    print("-"*60) 
    print("Gifts :") 
    print(gift)
    print("-"*60) 
    print("\n") 
    print(" "*23,"THANK YOU ^O^") 
    print("\n") 
    print("V"*60) 


bookname=[] 
bookamt=[] 
bookprice=[] 
customer=input("Customer: ") 
cashier=input("Cashier: ") 
bookinfo=book_info() 
while bookinfo=="1" or bookinfo=="2" or bookinfo=="3" or bookinfo =="4" or bookinfo=="5": 
    ask=input("Back to Book's Type?(Y/N): ") 
    while ask=="n"or ask=="N" or ask=="Y"or ask=="y": 
        if ask=="N"or ask=="n": 
            bookcollect=book_collect(bookinfo) 
            ask=input("Back to Book's Type?(Y/N): ") 
        else: 
            bookinfo=book_info() 
            break 
    else: 
        break 
print(">"*15,"System is log-out.","<"*15) 
fbookname=bookcollect[0] 
fbookprice=bookcollect[1] 
fbookamt=bookcollect[2] 
discal=dis_cal(fbookprice) 
gift=book_gift(discal) 
receipt=book_receipt() 